package com.example.ftness;

import android.app.Activity;

public class AboutActivity extends Activity {
}
