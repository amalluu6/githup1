package com.example.ftness;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;import android.content.Intent;
import android.content.pm.PackageManager;import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;import android.widget.EditText;
import android.widget.RadioButton;import android.widget.RadioGroup;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    Button aboutButton, callusButton, existButton,showButton,displaybutton ;
    EditText exerciseEditText ;
    RadioGroup radioGroupTrainers;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        aboutButton = findViewById(R.id.aboutButton);
        callusButton = findViewById(R.id.callusButton);
        existButton = findViewById(R.id.existButton);
        showButton = findViewById(R.id.showFeedButton);
        exerciseEditText = findViewById(R.id.exerciseEditText);
        radioGroupTrainers = findViewById(R.id.radioGroup);
            displaybutton= findViewById(R.id.displaybutton);
        aboutButton.setOnClickListener(v -> {



            startActivity(new Intent(MainActivity.this,next.class));

        });

        displaybutton.setOnClickListener(v -> {

                    startActivity(new Intent(MainActivity.this,next2.class));
                });

        callusButton.setOnClickListener(new View.OnClickListener() {
            @Override
        public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:+966555555555"));
            startActivity(i);            }
        });
        existButton.setOnClickListener(v-> {
            Toast.makeText(MainActivity.this,"Long-press to exist",Toast.LENGTH_SHORT).show();
        });
        existButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                finish();
                return false;
            }        });
        showButton.setOnClickListener(v -> {
            bookAppointment();
        });
    }

    private void bookAppointment() {
        String name =exerciseEditText.getText().toString();

        int selectedTrainerId = radioGroupTrainers.getCheckedRadioButtonId();        RadioButton selectedTrainer = findViewById(selectedTrainerId);
        String trainerName = selectedTrainer.getText().toString();
        String message = "exercise Name : "  + name + "\n proper feed: Vegetablse and fats" +  "\n Coach:"+ trainerName ;        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();


        aboutButton.setOnClickListener(v -> {

            startActivity(new Intent(MainActivity.this,next.class));


        });

    }}